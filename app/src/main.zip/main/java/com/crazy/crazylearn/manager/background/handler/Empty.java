package com.crazy.crazylearn.manager.background.handler;

public class Empty {

}

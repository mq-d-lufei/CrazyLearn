package com.crazy.crazylearn.manager.background;

import com.crazy.crazylearn.manager.background.handler.Empty;

public class ThreadSummary {


    public static void main(String[] arg) {

        ThreadSummary threadSummary = new ThreadSummary();

        threadSummary.classTest();

        System.out.println(" --------------- ");

        classStatic();
    }

    public void classTest() {

        Class<?> class0 = null;

        try {
            class0 = Class.forName("com.crazy.crazylearn.manager.background.handler.Empty");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("class0 : " + (null != class0 ? class0.hashCode() : " null "));

        Class class1 = Empty.class;

        System.out.println("class1 : " + class1.hashCode());

        Empty class2 = new Empty();

        System.out.println("class2 : " + class2.getClass().hashCode());


        Empty class3 = new Empty();

        System.out.println("class3 : " + class3.getClass().hashCode());
    }

    public static void classStatic() {

        Class<?> class0 = null;

        try {
            class0 = Class.forName("com.crazy.crazylearn.manager.background.ThreadSummary.StaticClass");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        System.out.println("class0 : " + (null != class0 ? class0.hashCode() : " null "));

        Class class1 = StaticClass.class;

        System.out.println("class1 : " + class1.hashCode());

        StaticClass class2 = new StaticClass();

        System.out.println("class2 : " + class2.getClass().hashCode());


        StaticClass class3 = new StaticClass();

        System.out.println("class3 : " + class3.getClass().hashCode());
    }


    public static class StaticClass {

    }

}


/***
 *
 *  概念相关
 *
 *  1、同步、异步
 *
 *  2、并发：多个任务交替执行，而多个任务有可能还是串行的
 *     并行：正在意义上的“同时执行”，多核CPU
 *
 *  3、临界区：共享资源（公共资源），可以被多个线程使用，但是每一次只能有一个线程使用它，
 *              一旦共享资源被占用，其他线程若想使用，必须等待
 *             受保护区，避免出现恩提
 *
 *  4、阻塞与非阻塞：多线程间的相互影响
 *
 *  5、死锁：十字路口堵车
 *
 *     饥饿：迟迟无法获得所需资源，导致一直无法执行，
 *              资源被高优先级线程抢占
 *              关键资源被另一个线程占着不放
 *
 *     活锁：线程间互相谦让，导致资源在现场见跳动，没有一个线程拿到资源而正常执行
 *
 *  6、并发级别
 *      阻塞
 *      无饥饿
 *      无障碍
 *      无锁
 *      无等待
 *
 *  JVM多线程
 *
 *  1、原子性：一个操作是不可中断的
 *
 *  2、可见性：一个线程修改了共享变量的值，其他线程是否能够立即知道这个修改
 *
 *  3、有序性：并发时，程序的执行可能出现乱序，可能会指令重排序，重排序后的指令与原指令未必一致
 *
 *
 *  Thread
 *
 *  1、NEW RUNNABLE BLOCKED WAITING TIMED_WAITING TERMINATED
 *
 *  2、Thread.stop()方法在结束线程时，会直接终止线程，并立即释放该线程持有的锁，可能会导致问题
 *
 *
 *  同步控制
 *
 *  1、Synchronized 线程间同步
 *
 *  2、ReentrantLock 重入锁
 *          中断响应
 *          锁申请等待限时
 *          公平锁
 *
 *  3、condition 重入锁搭档，与Object.wait()、Object.notify()大致相同
 *
 *  4、Semaphore 信行量 对锁的扩展 一次可以指定多个线程访问某一共享资源
 *
 *  5、ReentrantReadWriteLock 读写锁
 *
 *  6、CountDownLatch 倒计时器
 *      Latch 门闩
 *      让某一线程等待直到倒计时结束，再开始执行（该线程等待知道其他线程执行完再执行）
 *
 *  7、LockSupport 线程阻塞工具类
 *          可以在线程任意位置让线程阻塞
 *          与Object.wait()相比，不需要先获得某个对象的锁，不会抛出中断异常
 *
 *
 *
 *
 */
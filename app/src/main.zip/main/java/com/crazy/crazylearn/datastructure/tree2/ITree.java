package com.crazy.crazylearn.datastructure.tree2;

public interface ITree {
}

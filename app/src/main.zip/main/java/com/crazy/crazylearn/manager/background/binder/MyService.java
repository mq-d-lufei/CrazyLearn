package com.crazy.crazylearn.manager.background.binder;

import android.os.Binder;

public class MyService extends Binder {


}

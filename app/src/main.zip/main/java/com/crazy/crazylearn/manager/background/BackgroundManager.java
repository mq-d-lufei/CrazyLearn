package com.crazy.crazylearn.manager.background;

import android.content.Context;
import android.location.LocationManager;

import static android.content.Context.LOCATION_SERVICE;

public class BackgroundManager {

    public void initService(Context context) {

        LocationManager locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);


    }

    /**
     *
     * 1、线程
     *
     * 2、线程池
     *
     * 3、Handler
     *
     * 4、IntentService
     *
     * 5、Binder
     *
     *
     *
     *
     *
     *
     *
     */

    /***
     *
     *  一、unix中常见IPC :
     *      信号、管道、信号量、消息队列、共享存储、Unix域套接字
     *
     *  二、Android应用程序服务
     *
     *  三、Android 服务概要
     *      1、应用服务（Application）
     *          应用中通过继承Service后开发出来的
     *
     *      2、系统服务（Framework）
     *         Java系统服务（核心平台服务、硬件服务）------ Framework层提供
     *              在Android启动时，Java系统服务由SystemServer系统进程启动
     *              核心平台服务
     *                  ActivityManagerService
     *                  WindowManagerService
     *                  PacketManagerService
     *              硬件服务（用于控制底层硬件）
     *                  AlertManagerService
     *                  Location Manager Service
     *                  。。。。。。
     *
     *         本地系统服务 ------ Libraries层提供
     *             使用C++编写
     *
     *  四、运行系统服务
     *
     *      init --> 运行MediaServer进程  --> 启动本地系统服务（除了SurfaceFlinger）
     *           --> 运行Zygote进程 --> 运行SystemServer进程 --> 运行Java系统服务
     *
     *  五、媒体服务器（MediaServer）
     *      是系统进程、运行本地系统服务、有init进程启动运行
     *      创建各个本地服务实例对象，并注册服务到ContextManager
     *
     *  六、系統服務（SystemServer）
     *      是Java进程，有Zygote进程生成，运行在Dalvik虚拟机中的Java进程，运行多种Java系统服务，还有SufaceFlinger本地系统服务
     *
     *
     *
     *
     */


    /**
     *
     * 内核剖析
     *
     * 零、 Binder
     *
     * 问题：
     *  1、服务端、客户端、驱动端通讯过程
     *  2、设计方式
     *  3、数据封装传递解析过程
     *  4、调用过程
     *
     * 一、Binder 开始
     *
     * 1、客户端想要访问远程服务，必须获得远程服务在Binder对象中对应的onRemote引用，
     * 2、先挂起客户端线程-->等待服务端线程执行，完成，通知客户度线程-->客户端线程继续执行
     * 3、通过Binder驱动进行中转，故，存在两个Binder对象，一个是服务端Binder对象，
     *      另一个是Binder驱动中的Binder对象，Binder驱动中的对象不会在额外产生一个线程
     *
     *
     * 二、设计Server端
     *
     * 1、继续Binder类，
     * 2、public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
     *    重载onTrasact()方法，并从data变量中取出客户端传递的参数
     * 3、code变量：用于标识客户端期望调用服务端的哪个函数，所以双发需要约定一组int值，
     *      不同值代表不同服务端函数，客户顿transact()函数中使用
     * 4、enforceInterface():为了某种校验，与客户端的writeInterfaceToken()对应
     * 5、readString():用于重包裹中读取一个字符串
     * 6、reply： 该IPC调用的客户端期望返回的结果,可写入返回数据
     *
     * 三、设计Client端
     *
     * 1、要想使用服务端，首先需要获取服务端在Binder驱动中对mRemote变量的引用
     * 2、parcel 数据包裹类，常用原子类型，继承与Parcel类的数据，
     *      包裹中添加的内容是有序的，客户端与服务端约定好的
     * 3、服务端onTransact()、客户端transact()
     * 4、客戶端調用transact方法后客戶端進入Binder驱动，Binder驱动挂起当前线程，并向远程服务发起消息（Parcel包裹）
     *      服务端拿到包裹数据后会拆解，然后执行指定的服务函数，执行完毕后，再把执行结果繁荣reply包裹中，然后服务端
     *      想Binder驱动发送notify消息，从而使客户端线程从Binder驱动代码区返回到客户端代码区
     * 5、客户端解析reply包裹数据，完成一次调用
     *
     *
     * 四、使用Service类
     *
     * 1、手工写Binder服务端和客户端存在两个重要问题
     *      a、客户端如何获取服务端Binder对象的引用
     *      b、客户端与服务端必须事先约定两件事
     *          data包裹Parcel中个数据的顺序
     *          服务端不同函数的int标识
     *
     * 2、获取Binder对象
     *
     *
     *
     *
     *
     */


    /**
     *
     * Context 場景  上下文
     *      Activity基於Context，Service也基于Context
     *      但也都实现了一些其他的接口，接口实现功能，继承才是类的本质
     *      Context总数 = Activity + Service + 1（Application）
     *
     */

    /**
     *
     * ActivityManagerService
     *
     *  1、統一调度各应用程序的Activity
     *  2、内存管理，Activity推出后合适杀死等内存问题
     *  3、进程管理，向外提供了查询系统正在运行的进程信息API
     *
     *  Activity调度
     *      各应用进程启动新的Activity或停止当前Activity，都要首先报告给AMS
     *
     *
     */

    /***
     *
     * APK程序的运行过程
     *
     *
     *
     *
     *
     *
     *
     */
}



package com.crazy.crazylearn.manager.background.thread;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ThreadPoolSummary {

    public ThreadPoolSummary() {
    }

    public static void main(String[] args) {

        ThreadPoolSummary threadPoolSummary = new ThreadPoolSummary();

        threadPoolSummary.test1();
    }

    /**
     * 固定大小线程池
     */
    public Executor executor = Executors.newFixedThreadPool(5);
    public Executor singleExecutor = Executors.newSingleThreadExecutor();

    private Executor cacheExecutor = Executors.newCachedThreadPool();


    public class ExecutorRunnable implements Runnable {

        public String name;

        @Override
        public void run() {

            long time = System.currentTimeMillis();
            long id = Thread.currentThread().getId();

            System.out.println("time = " + time + " thread-id = " + id);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void test1() {

        ExecutorRunnable executorRunnable = new ExecutorRunnable();

        for (int i = 0; i < 10; i++) {
            cacheExecutor.execute(executorRunnable);
        }

    }

    public Executor iexecutor;
    private ExecutorService executorService;
    private ThreadPoolExecutor threadPoolExecutor;

    public class MyThreadPool extends ThreadPoolExecutor {

        public MyThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
            super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
        }

        @Override
        protected void beforeExecute(Thread t, Runnable r) {
            super.beforeExecute(t, r);
            System.out.println("准备执行： " + ((ExecutorRunnable) r).name);
        }

        @Override
        protected void afterExecute(Runnable r, Throwable t) {
            super.afterExecute(r, t);
            System.out.println("准备完成： ");
        }

        @Override
        protected void terminated() {
            super.terminated();
            System.out.println("线程池退出");
        }
    }


    private ExecutorService futrueExecutor = Executors.newFixedThreadPool(5);

    public void test2() {

        futrueExecutor.submit(new Runnable() {
            @Override
            public void run() {

            }
        });

        Callable<String> callable = new Callable<String>() {
            @Override
            public String call() throws Exception {
                return "result = ";
            }
        };

        FutureTask<String> future = new FutureTask<String>(callable);

        futrueExecutor.submit(new Callable<String>() {
            @Override
            public String call() throws Exception {
                return "";
            }
        });
    }


}
